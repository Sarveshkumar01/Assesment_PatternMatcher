package com.thales.wordSearchExcercise;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//class to control the app
//responsible to accept user input and display output
public class PatternSearchController {

	public static void main(String[] args) {
		// input file in which user search the pattern 
		String filePath= "C:\\Users\\s0068240\\MyApp\\Git_WorkSpace\\ThalesWordSearch\\src\\wordSearch.csv";
		String pattern="";
		
		try {
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));  
			System.out.println("Enter a Word"); 
			pattern=br.readLine();			
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		PatternSearchModel patternSearchModel = new PatternSearchModel(filePath);
		System.out.println("pattern "+pattern+" found " + patternSearchModel.patternSearch(pattern) + " times");
		
		
	}

}
