package com.thales.wordSearchExcercise;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

// class responsible to read the input file and covert it into 2D array for search the pattern
public class InputFileData {
	private String filePath="";
	
	//2D grid created from input file
	private String [][] patternGrid= new String [0][0];
	
	// rows of grid
	private int row;
	
	//columns of grid
	private int column;
	
	//constructor
	public InputFileData(String path) {
		filePath = path;
		createInputDataGrid();
	}
	
	//method to create the 2D grid from input file
	private void createInputDataGrid() {
		int rowCount=0;
		
		try {
			BufferedReader in = Files.newBufferedReader(Paths.get(filePath));
			List<String> inputFileData=  in.lines().collect(Collectors.toList());
			row=inputFileData.size();
			if(row!=0) {
				column=(inputFileData.get(0).split(",")).length;
			}
			patternGrid=new String [row][column];
			Iterator iterator=inputFileData.iterator();
			while(iterator.hasNext()) {
				String listLine=(String)iterator.next();
				String [] line=listLine.split(",");
				for(int j=0; j<line.length; j++) {
					patternGrid[rowCount][j]=line[j];
				}
				
				rowCount++;
			}
			
		}
		catch (IOException e) {
			e.printStackTrace();
		}
				
	}
	
	// getter for pattern grid
	public String[][] getPatternGrid() {
		return patternGrid;
	}

	//getter will return the number of rows
	public int getRow() {
		return row;
	}

	//getter will return number of columns
	public int getColumn() {
		return column;
	}

}
