package com.thales.wordSearchExcercise;
//class to check the pattern is present in given file data
public class PatternSearchModel {
	
	//specification of data present in input file
	private InputFileData reader;
	
	//number of rows present in input file
	private int row;
	
	//number of columns present in input file
	private int column;
	
	//file coverted in 2D grid
	private String [][] grid;
	
	// For searching in all 8 direction
	static int[] x = { -1, -1, -1, 0, 0, 1 };
	static int[] y = { -1, 0, 1, -1, 1, -1 };
	
	//constructor
	// file path : string type :path of the input file
	public PatternSearchModel(String filePath) {
		reader= new InputFileData(filePath);		
		grid=reader.getPatternGrid();
		row=reader.getRow();
		column=reader.getColumn();
	}
	
	//method to search the input pattern in 2d grid
	// return count of match found in grid
	public int patternSearch(String word)
	{
		int matchCount=0;
		// Consider every point as starting
		// point and search given word
		Boolean result=false;
		for (int gridRow = 0; gridRow < row; gridRow++) {
			for (int gridCol = 0; gridCol < column; gridCol++) {
				
				if (searchInGrid(grid, gridRow, gridCol, word)) {
					matchCount++;
					System.out.println("pattern found at " + gridRow + ", " + gridCol);
				}
			}
		}
		return matchCount;
	}

	// This function searches in all
	// 8-direction from point
	// (Row, Column) in grid[][]
	private boolean searchInGrid(String[][] grid, int gridRow, int gridCol, String word) {
		
			// If first character of word
			// doesn't match with
			// given starting point in grid.
			if (Character.toLowerCase((grid[gridRow][gridCol]).charAt(0)) != Character.toLowerCase(word.charAt(0))) {
				return false;
			}
			
			int wordLength = word.length();

			// Search word in all 8 directions
			// starting from (gridRow, gridCol)
			for (int dir = 0; dir < 6; dir++) {
				// Initialize starting point
				// for current direction
				int k, rd = gridRow + x[dir], cd = gridCol + y[dir];

				// First character is already checked,
				// match remaining characters
				for (k = 1; k < wordLength; k++) {
					// If out of bound break
					if (rd >= row || rd < 0 || cd >= column || cd < 0)
						break;

					// If not matched, break
					if (Character.toLowerCase(grid[rd][cd].charAt(0)) != Character.toLowerCase(word.charAt(k)))
						break;

					// Moving in particular direction
					rd += x[dir];
					cd += y[dir];
				}

				// If all character matched,
				// then value must be equal to length of word
				if (k == wordLength)
					return true;
			}
		return false;
	}
}
